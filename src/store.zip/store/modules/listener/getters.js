/* ============
 * Getters for the Listener module
 * ============
 *
 * The getters that are available on the
 * listener module.
 */

export default {};
